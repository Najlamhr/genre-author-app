<?php
namespace App\Http\Controllers;

use App\Models\Author;
use Illuminate\Http\Request;

class AuthorController extends Controller
{
    public function index()
    {
        return response()->json(Author::all());
    }

    public function store(Request $request)
    {
        $request->validate(['name' => 'required']);
        $author = Author::create(['name' => $request->name]);
        return response()->json($author, 201);
    }
}
