<?php
namespace App\Http\Controllers;

use App\Models\Genre;  // pastikan import model yang benar
use Illuminate\Http\Request;

class GenreController extends Controller
{
    public function index()
    {
        return response()->json(Genre::all());
    }

    public function store(Request $request)
    {
        $request->validate(['name' => 'required']);
        $genre = Genre::create(['name' => $request->name]);
        return response()->json($genre, 201);
    }
}
