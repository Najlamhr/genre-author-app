<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Author;

class AuthorSeeder extends Seeder
{
    public function run()
    {
        Author::insert([
            ['name' => 'Tere Liye', 'bio' => 'Penulis novel inspiratif.'],
            ['name' => 'Andrea Hirata', 'bio' => 'Penulis Laskar Pelangi.'],
            ['name' => 'Dewi Lestari', 'bio' => 'Penulis Filosofi Kopi.'],
            ['name' => 'Habiburrahman El Shirazy', 'bio' => 'Penulis Ayat-Ayat Cinta.'],
            ['name' => 'Ahmad Fuadi', 'bio' => 'Penulis Negeri 5 Menara.'],
        ]);
    }
}
