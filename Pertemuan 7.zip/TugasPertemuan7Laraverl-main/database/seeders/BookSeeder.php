<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Book;

class BookSeeder extends Seeder
{
    public function run()
    {
        Book::insert([
            ['title' => 'Rindu', 'author_id' => 1, 'year' => 2015, 'genre' => 'Drama'],
            ['title' => 'Laskar Pelangi', 'author_id' => 2, 'year' => 2005, 'genre' => 'Inspirasi'],
            ['title' => 'Filosofi Kopi', 'author_id' => 3, 'year' => 2006, 'genre' => 'Fiksi'],
            ['title' => 'Ayat-Ayat Cinta', 'author_id' => 4, 'year' => 2004, 'genre' => 'Religi'],
            ['title' => 'Negeri 5 Menara', 'author_id' => 5, 'year' => 2009, 'genre' => 'Motivasi'],
        ]);
    }
}
